# C:\Archive 5\harmo\urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),

    # your marketing site / landing pages
    path("", include("major.urls")),

    # dashboard app
    path("dashboard/", include("dashboard.home.urls")),

    # auth (login/logout/password reset pages)
    path("accounts/", include("django.contrib.auth.urls")),
]
