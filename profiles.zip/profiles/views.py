# profiles/views.py
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib import messages

from .models import Profile

@login_required
def edit_profile(request):
    profile, _ = Profile.objects.get_or_create(user=request.user)

    if request.method == "POST":
        request.user.first_name = request.POST.get("first_name", "").strip()
        request.user.last_name  = request.POST.get("last_name", "").strip()
        request.user.email      = request.POST.get("email", "").strip()
        request.user.save()

        profile.phone   = request.POST.get("phone", "").strip()
        profile.country = request.POST.get("country", "").strip()
        profile.save()

        messages.success(request, "Profile updated.")
        return redirect("user-home")  # adjust if your dashboard name differs

    return render(request, "profiles/edit_profile.html", {"profile": profile})
