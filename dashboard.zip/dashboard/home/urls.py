# dashboard/home/urls.py
from django.urls import path
from . import views

# NOTE: no app_name on purpose, so plain names like 'user-home' resolve.

urlpatterns = [
    path("user/", views.index, name="user-home"),

    # pages your templates link to
    path("plans/", views.PlansView.as_view(), name="plans"),
    path("invest/", views.InvestView.as_view(), name="invest"),
    path("investments/", views.InvestmentView.as_view(), name="investments"),
    path("withdraw/", views.WithdrawalView.as_view(), name="withdraw"),
    path("crypto-withdraw/", views.CryptoWithdrawalView.as_view(), name="crypto_withdraw"),
    path("charts/", views.ChartView.as_view(), name="charts"),
    path("verification-sent/", views.VerificationView.as_view(), name="verification-sent"),
]
