# C:\Archive 5\dashboard\home\views.py
from django.contrib.auth.decorators import login_required
from django.shortcuts import render

@login_required
def index(request):
    # You already had this — keep your existing context if you prefer.
    context = {
        "balances": [
            {"symbol": "BTC", "amount": 0.248, "usd": 7050},
            {"symbol": "ETH", "amount": 1.75, "usd": 5600},
        ],
    }
    return render(request, "home/dashboard2.html", context)

@login_required
def invest(request):
    return render(request, "home/placeholder.html", {"title": "Make Deposits"})

@login_required
def plans(request):
    return render(request, "home/placeholder.html", {"title": "Plans"})

@login_required
def edit_profile(request):
    return render(request, "home/placeholder.html", {"title": "Edit Profile"})
